document.addEventListener('DOMContentLoaded', function() {
    const loginForm = document.querySelector('form');
    
    loginForm.addEventListener('submit', function(event) {
        event.preventDefault();
        
        const username = document.getElementById('username').value;
        const password = document.getElementById('password').value;
        
        if (username === '' || password === '') {
            alert('Please enter both username and password.');
        } else {
            alert('Login successful!'); 
            // Here, you can add more functionality, such as sending data to the server.
        }
    });
});
