document.addEventListener("DOMContentLoaded", () => {
    
    function toggletalk() {
        alert("Let's Talk button Clicked!");
    }
    
    function togglegrowth() {
        alert("Growth button Clicked!");
    }
   
    function togglemarketing() {
        alert("Marketing button Clicked!");
    }

    function togglestarted() {
        alert("Get Started button Clicked!");
    }
    

    function togglefstart() {
        alert("Focused on Growth Start!!");
    }

    function togglebigpartner() {
        alert("Big Partner button Clicked!");
    }

    function toggleaboutus() {
        alert("Let's See About Us!");
    }

    function togglestarted2() {
        alert("Get Started button Clicked!");
    }

    function toggleserviced() {
        alert("Service button Clicked!");
    }

    function togglessstarted() {
        alert("Get Started🡭");
    }

    function togglewhychooseus() {
        alert("Why Choose us, button clicked!");
    }

    function togglewcustart() {
        alert("Focused on Growth Start!!");
    }

    function toggleproject() {
        alert("Let's see our Projects!!");
    }

    function toggleprowjoin() {
        alert("You will Join us Now!!");
    }

    function toggleproadd() {
        alert("We will show you the Advertising Project!");
    }

    function toggleptcsmmp() {
        alert("Let's see Social Media Marketing Project!");
    }

    function toggletsteam() {
        alert("We will show you Our Best Team!");
    }

    function toggleplanpri() {
        alert("Let's see Plans & Pricing!");
    }

    function togglesubmonth() {
        alert("Let's see our monthly Plans!");
    }

    function togglesubannu() {
        alert("Let's see our annualy Plans!");
    }

    function togglegrowthpack() {
        alert("Let's see our Growth Package Plans!");
    }

    function togglegpgs() {
        alert("Let's Get Started Growth Package Plans!");
    }

    function togglepremiumpack() {
        alert("Let's see our Premium Package Plans!");
    }

    function togglepregs() {
        alert("Let's Get Started Premium Package Plans!");
    }

    function toggletmbtn() {
        alert("Testimonials button clicked!!");
    }

    document.querySelector(".talk-btn").addEventListener("click", toggletalk);
    document.querySelector(".growth-btn").addEventListener("click", togglegrowth);
    document.querySelector(".marketing-btn").addEventListener("click", togglemarketing);
    document.querySelector(".started-btn").addEventListener("click", togglestarted);
    document.querySelector(".fstartbtn").addEventListener("click", togglefstart);
    document.querySelector(".bigpartner-btn").addEventListener("click", togglebigpartner);
    document.querySelector(".aboutus-btn").addEventListener("click", toggleaboutus);
    document.querySelector(".started-btn2").addEventListener("click", togglestarted2);
    document.querySelector(".serviced-btn").addEventListener("click", toggleserviced);
    document.querySelector(".s-started").addEventListener("click", togglessstarted);
    document.querySelector(".whychooseus-btn").addEventListener("click", togglewhychooseus);
    document.querySelector(".wcu-startbtn").addEventListener("click", togglewcustart);
    document.querySelector(".projectbtn").addEventListener("click", toggleproject);
    document.querySelector(".prowjoin-btn").addEventListener("click", toggleprowjoin);
    document.querySelector(".proadd-btn").addEventListener("click", toggleproadd);
    document.querySelector(".ptcsmmp-btn").addEventListener("click", toggleptcsmmp);
    document.querySelector(".ts-team").addEventListener("click", toggletsteam);
    document.querySelector(".planpri").addEventListener("click", toggleplanpri);
    document.querySelector(".sub-month").addEventListener("click", togglesubmonth);
    document.querySelector(".sub-annu").addEventListener("click", togglesubannu);
    document.querySelector("#growth-pack-btn").addEventListener("click", togglegrowthpack);
    document.querySelector(".gp-gs").addEventListener("click", togglegpgs);
    document.querySelector("#premium-pack-btn").addEventListener("click", togglepremiumpack);
    document.querySelector(".pre-gs").addEventListener("click", togglepregs);
    document.querySelector(".tm-btn").addEventListener("click", toggletmbtn);

});

