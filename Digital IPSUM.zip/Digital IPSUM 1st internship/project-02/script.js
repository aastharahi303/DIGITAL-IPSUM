document.addEventListener("DOMContentLoaded", function () {
    const slider = document.getElementById("slider");
    const controls = document.getElementById("controls");
    const slides = document.querySelectorAll(".slide");
    let currentIndex = 0;

    // Create navigation dots dynamically
    slides.forEach((_, index) => {
        const dot = document.createElement("div");
        dot.dataset.index = index;
        dot.addEventListener("click", function () {
            currentIndex = index;
            updateSlider();
        });
        controls.appendChild(dot);
    });

    function updateSlider() {
        slider.style.transform = `translateY(-${currentIndex * 100}vh)`;
        document.querySelectorAll(".controls div").forEach((dot, index) => {
            dot.style.opacity = index === currentIndex ? "1" : "0.5";
        });
    }

    updateSlider(); // Initialize slider state
});
